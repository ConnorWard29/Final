﻿using PokemonTCG.Objects;
using System;
using System.Windows.Forms;

namespace PokemonTCG
{
    public partial class Form1 : Form
    {
        //Setting up variables for later use.
        string selectedSet;
        int cardAmount = 0;
        int cardID = 0;
        string Subtype = "Subtypes: ";

        //Initializing Form
        public Form1()
        {
            InitializeComponent();
        }

        //Selecting Item On setList, assigning it to selectedSet, and displaying number of cards in set
        private void setList_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            selectedSet = setList.SelectedItem.ToString();
            //Base Series Set Numbers
            if (selectedSet == "base1")
            {
                cardsInSet.Text = "102";
            }
            if (selectedSet == "base2")
            {
                cardsInSet.Text = "64";
            }
            if (selectedSet == "base3")
            {
                cardsInSet.Text = "62";
            }
            if (selectedSet == "base4")
            {
                cardsInSet.Text = "130";
            }
            if (selectedSet == "base5")
            {
                cardsInSet.Text = "82";
            }
            if (selectedSet == "base6")
            {
                cardsInSet.Text = "110";
            }
            //Black & White Series Set Numbers
            if (selectedSet == "bw1")
            {
                cardsInSet.Text = "114";
            }
            if (selectedSet == "bw2")
            {
                cardsInSet.Text = "98";
            }
            if (selectedSet == "bw3")
            {
                cardsInSet.Text = "101";
            }
            if (selectedSet == "bw4")
            {
                cardsInSet.Text = "99";
            }
            if (selectedSet == "bw5")
            {
                cardsInSet.Text = "108";
            }
            if (selectedSet == "bw6")
            {
                cardsInSet.Text = "124";
            }
            if (selectedSet == "bw7")
            {
                cardsInSet.Text = "149";
            }
            if (selectedSet == "bw8")
            {
                cardsInSet.Text = "135";
            }
            if (selectedSet == "bw9")
            {
                cardsInSet.Text = "116";
            }
            if (selectedSet == "bw10")
            {
                cardsInSet.Text = "101";
            }
            if (selectedSet == "bw11")
            {
                cardsInSet.Text = "113";
            }
            //Others Series Set Numbers
            if (selectedSet == "col1")
            {
                cardsInSet.Text = "95";
            }
            if (selectedSet == "dc1")
            {
                cardsInSet.Text = "34";
            }
            if (selectedSet == "det1")
            {
                cardsInSet.Text = "18";
            }
            //Diamond & Pearl Series Set Numbers
            if (selectedSet == "dp1")
            {
                cardsInSet.Text = "130";
            }
            if (selectedSet == "dp2")
            {
                cardsInSet.Text = "123";
            }
            if (selectedSet == "dp3")
            {
                cardsInSet.Text = "132";
            }
            if (selectedSet == "dp4")
            {
                cardsInSet.Text = "106";
            }
            if (selectedSet == "dp5")
            {
                cardsInSet.Text = "100";
            }
            if (selectedSet == "dp6")
            {
                cardsInSet.Text = "146";
            }
            if (selectedSet == "dp7")
            {
                cardsInSet.Text = "100";
            }
            if (selectedSet == "dv1")
            {
                cardsInSet.Text = "20";
            }
            //ECard Series Set Numbers
            if (selectedSet == "ecard1")
            {
                cardsInSet.Text = "165";
            }
            if (selectedSet == "ecard2")
            {
                cardsInSet.Text = "147";
            }
            if (selectedSet == "ecard3")
            {
                cardsInSet.Text = "144";
            }
            //EX Series Set Numbers
            if (selectedSet == "ex1")
            {
                cardsInSet.Text = "109";
            }
            if (selectedSet == "ex2")
            {
                cardsInSet.Text = "100";
            }
            if (selectedSet == "ex3")
            {
                cardsInSet.Text = "97";
            }
            if (selectedSet == "ex4")
            {
                cardsInSet.Text = "95";
            }
            if (selectedSet == "ex5")
            {
                cardsInSet.Text = "101";
            }
            if (selectedSet == "ex6")
            {
                cardsInSet.Text = "112";
            }
            if (selectedSet == "ex7")
            {
                cardsInSet.Text = "109";
            }
            if (selectedSet == "ex8")
            {
                cardsInSet.Text = "107";
            }
            if (selectedSet == "ex9")
            {
                cardsInSet.Text = "106";
            }
            if (selectedSet == "ex10")
            {
                cardsInSet.Text = "115";
            }
            if (selectedSet == "ex11")
            {
                cardsInSet.Text = "113";
            }
            if (selectedSet == "ex12")
            {
                cardsInSet.Text = "92";
            }
            if (selectedSet == "ex13")
            {
                cardsInSet.Text = "110";
            }
            if (selectedSet == "ex14")
            {
                cardsInSet.Text = "100";
            }
            if (selectedSet == "ex15")
            {
                cardsInSet.Text = "101";
            }
            if (selectedSet == "ex16")
            {
                cardsInSet.Text = "108";
            }
            //Generations Series Set Numbers
            if (selectedSet == "g1")
            {
                cardsInSet.Text = "83";
            }
            //Gym Series Set Numbers
            if (selectedSet == "gym1")
            {
                cardsInSet.Text = "132";
            }
            if (selectedSet == "gym2")
            {
                cardsInSet.Text = "132";
            }
            //Heart Gold & Soul Silver Series Set Numbers
            if (selectedSet == "hgss1")
            {
                cardsInSet.Text = "123";
            }
            if (selectedSet == "hgss2")
            {
                cardsInSet.Text = "95";
            }
            if (selectedSet == "hgss3")
            {
                cardsInSet.Text = "90";
            }
            if (selectedSet == "hgss4")
            {
                cardsInSet.Text = "102";
            }
            //McDonalds Series Set Numbers
            if (selectedSet == "mcd11")
            {
                cardsInSet.Text = "12";
            }
            if (selectedSet == "mcd12")
            {
                cardsInSet.Text = "12";
            }
            if (selectedSet == "mcd16")
            {
                cardsInSet.Text = "12";
            }
            if (selectedSet == "mcd19")
            {
                cardsInSet.Text = "12";
            }
            //Neo Series Set Numbers
            if (selectedSet == "neo1")
            {
                cardsInSet.Text = "111";
            }
            if (selectedSet == "neo2")
            {
                cardsInSet.Text = "75";
            }
            if (selectedSet == "neo3")
            {
                cardsInSet.Text = "66";
            }
            if (selectedSet == "neo4")
            {
                cardsInSet.Text = "105";
            }
            {
                cardsInSet.Text = "40";
            }
            //Platinuim Series Set Numbers
            if (selectedSet == "pl1")
            {
                cardsInSet.Text = "127";
            }
            if (selectedSet == "pl2")
            {
                cardsInSet.Text = "111";
            }
            if (selectedSet == "pl3")
            {
                cardsInSet.Text = "147";
            }
            if (selectedSet == "pl4")
            {
                cardsInSet.Text = "99";
            }
            //Pop Series Set Numbers
            if (selectedSet == "pop1")
            {
                cardsInSet.Text = "17";
            }
            if (selectedSet == "pop2")
            {
                cardsInSet.Text = "17";
            }
            if (selectedSet == "pop3")
            {
                cardsInSet.Text = "17";
            }
            if (selectedSet == "pop4")
            {
                cardsInSet.Text = "17";
            }
            if (selectedSet == "pop5")
            {
                cardsInSet.Text = "17";
            }
            if (selectedSet == "pop6")
            {
                cardsInSet.Text = "17";
            }
            if (selectedSet == "pop7")
            {
                cardsInSet.Text = "17";
            }
            if (selectedSet == "pop8")
            {
                cardsInSet.Text = "17";
            }
            if (selectedSet == "pop9")
            {
                cardsInSet.Text = "17";
            }
            //Others Series Set Numbers
            if (selectedSet == "ru1")
            {
                cardsInSet.Text = "16";
            }
            if (selectedSet == "si1")
            {
                cardsInSet.Text = "18";
            }
            //Sun & Moon Series Set Numbers
            if (selectedSet == "sm1")
            {
                cardsInSet.Text = "149";
            }
            if (selectedSet == "sm2")
            {
                cardsInSet.Text = "145";
            }
            if (selectedSet == "sm3")
            {
                cardsInSet.Text = "147";
            }
            if (selectedSet == "sm35")
            {
                cardsInSet.Text = "73";
            }
            if (selectedSet == "sm4")
            {
                cardsInSet.Text = "111";
            }
            if (selectedSet == "sm5")
            {
                cardsInSet.Text = "156";
            }
            if (selectedSet == "sm6")
            {
                cardsInSet.Text = "131";
            }
            if (selectedSet == "sm7")
            {
                cardsInSet.Text = "168";
            }
            if (selectedSet == "sm75")
            {
                cardsInSet.Text = "70";
            }
            if (selectedSet == "sm8")
            {
                cardsInSet.Text = "214";
            }
            if (selectedSet == "sm9")
            {
                cardsInSet.Text = "181";
            }
            if (selectedSet == "sm10")
            {
                cardsInSet.Text = "214";
            }
            if (selectedSet == "sm11")
            {
                cardsInSet.Text = "236";
            }
            if (selectedSet == "sm115")
            {
                cardsInSet.Text = "68";
            }
            if (selectedSet == "sm12")
            {
                cardsInSet.Text = "236";
            }
            //Sword & Shield Series Set Numbers
            if (selectedSet == "swsh1")
            {
                cardsInSet.Text = "202";
            }
            if (selectedSet == "swsh2")
            {
                cardsInSet.Text = "192";
            }
            if (selectedSet == "swsh3")
            {
                cardsInSet.Text = "189";
            }
            if (selectedSet == "swsh35")
            {
                cardsInSet.Text = "73";
            }
            if (selectedSet == "swsh4")
            {
                cardsInSet.Text = "185";
            }
            if (selectedSet == "swsh45")
            {
                cardsInSet.Text = "72";
            }
            if (selectedSet == "swsh45sv")
            {
                cardsInSet.Text = "112";
            }
            if (selectedSet == "swsh5")
            {
                cardsInSet.Text = "163";
            }
            //X & Y Series Set Numbers
            if (selectedSet == "xy0")
            {
                cardsInSet.Text = "39";
            }
            if (selectedSet == "xy1")
            {
                cardsInSet.Text = "146";
            }
            if (selectedSet == "xy2")
            {
                cardsInSet.Text = "106";
            }
            if (selectedSet == "xy3")
            {
                cardsInSet.Text = "111";
            }
            if (selectedSet == "xy4")
            {
                cardsInSet.Text = "119";
            }
            if (selectedSet == "xy5")
            {
                cardsInSet.Text = "160";
            }
            if (selectedSet == "xy6")
            {
                cardsInSet.Text = "108";
            }
            if (selectedSet == "xy7")
            {
                cardsInSet.Text = "98";
            }
            if (selectedSet == "xy8")
            {
                cardsInSet.Text = "162";
            }
            if (selectedSet == "xy9")
            {
                cardsInSet.Text = "122";
            }
            if (selectedSet == "xy10")
            {
                cardsInSet.Text = "124";
            }
            if (selectedSet == "xy11")
            {
                cardsInSet.Text = "114";
            }
            if (selectedSet == "xy12")
            {
                cardsInSet.Text = "108";
            }
        }

        private async void generateCardBtn_ClickAsync(object sender, EventArgs e)
        {
            if (cardsInSet.Text == "")
            {
                MessageBox.Show("Select a set first");
            }
            else
            {
                if (cardNumberInput.Text == "")
                {
                    MessageBox.Show("Enter a card id first");
                }
                else
                {
                    cardAmount = int.Parse(cardsInSet.Text);
                    cardID = int.Parse(cardNumberInput.Text);
                    if (cardID <= 0 || cardID > cardAmount)
                    {
                        MessageBox.Show("Enter a valid card ID");
                    }
                    else
                    {
                        Card generatedCard = await JSONHelper.GeneratePokemonCard(selectedSet, cardID);
                        //Subtype List to String
                        if (generatedCard.data.subtypes == null)
                        {
                            Subtype = Subtype + "Null";
                        }
                        else
                        {
                            Subtype = Subtype + generatedCard.data.subtypes[0];
                        }
                        //Basic Information
                        NameTxt.Text = "Card Name: " + generatedCard.data.name;
                        SupertypeTxt.Text = "Supertype: " + generatedCard.data.supertype;
                        SubtypeTxt.Text = Subtype;
                        NumberTxt.Text = "Number: " + generatedCard.data.number;
                        ArtistTxt.Text = "Artist: " + generatedCard.data.artist;
                        RarityTxt.Text = "Rarity: " + generatedCard.data.rarity;
                        //Set Information
                        SetNameTxt.Text = "Set Name: " + generatedCard.data.set.name;
                        SetSeriesTxt.Text = "Series: " + generatedCard.data.set.series;
                        PrintedTotalTxt.Text = "Printed Total: " + generatedCard.data.set.printedTotal;
                        TotalTxt.Text = "Total: " + generatedCard.data.set.total;
                        ReleaseDateTxt.Text = "Release Date: " + generatedCard.data.set.releaseDate;
                        //Legalities Information
                        CardLegalTxt.Text = "Card Legalities: " + generatedCard.data.legalities.unlimited;
                        SetLegalTxt.Text = "Set Legalities: " + generatedCard.data.set.legalities.unlimited;
                    }
                }
            }
        }
    }
}
