﻿
namespace PokemonTCG
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.setList = new System.Windows.Forms.ListBox();
            this.SelectSetLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cardsInSet = new System.Windows.Forms.Label();
            this.generateCardBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cardNumberInput = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RarityTxt = new System.Windows.Forms.Label();
            this.ArtistTxt = new System.Windows.Forms.Label();
            this.NumberTxt = new System.Windows.Forms.Label();
            this.SubtypeTxt = new System.Windows.Forms.Label();
            this.SupertypeTxt = new System.Windows.Forms.Label();
            this.NameTxt = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ReleaseDateTxt = new System.Windows.Forms.Label();
            this.TotalTxt = new System.Windows.Forms.Label();
            this.PrintedTotalTxt = new System.Windows.Forms.Label();
            this.SetSeriesTxt = new System.Windows.Forms.Label();
            this.SetNameTxt = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.SetLegalTxt = new System.Windows.Forms.Label();
            this.CardLegalTxt = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // setList
            // 
            this.setList.FormattingEnabled = true;
            this.setList.Items.AddRange(new object[] {
            "base1",
            "base2",
            "base3",
            "base4",
            "base5",
            "base6",
            "bw1",
            "bw10",
            "bw11",
            "bw2",
            "bw3",
            "bw4",
            "bw5",
            "bw6",
            "bw7",
            "bw8",
            "bw9",
            "col1",
            "dc1",
            "det1",
            "dp1",
            "dp2",
            "dp3",
            "dp4",
            "dp5",
            "dp6",
            "dp7",
            "dv1",
            "ecard1",
            "ecard2",
            "ecard3",
            "ex1",
            "ex10",
            "ex11",
            "ex12",
            "ex13",
            "ex14",
            "ex15",
            "ex16",
            "ex2",
            "ex3",
            "ex4",
            "ex5",
            "ex6",
            "ex7",
            "ex8",
            "ex9",
            "g1",
            "gym1",
            "gym2",
            "hgss1",
            "hgss2",
            "hgss3",
            "hgss4",
            "mcd11",
            "mcd12",
            "mcd16",
            "mcd19",
            "neo1",
            "neo2",
            "neo3",
            "neo4",
            "np",
            "pl1",
            "pl2",
            "pl3",
            "pl4",
            "pop1",
            "pop2",
            "pop3",
            "pop4",
            "pop5",
            "pop6",
            "pop7",
            "pop8",
            "pop9",
            "ru1",
            "si1",
            "sm1",
            "sm10",
            "sm11",
            "sm115",
            "sm12",
            "sm2",
            "sm3",
            "sm35",
            "sm4",
            "sm5",
            "sm6",
            "sm7",
            "sm75",
            "sm8",
            "sm9",
            "sma",
            "swsh1",
            "swsh2",
            "swsh3",
            "swsh35",
            "swsh4",
            "swsh45",
            "swsh45sv",
            "swsh5",
            "xy1",
            "xy10",
            "xy11",
            "xy12",
            "xy2",
            "xy3",
            "xy4",
            "xy5",
            "xy6",
            "xy7",
            "xy8",
            "xy9"});
            this.setList.Location = new System.Drawing.Point(12, 31);
            this.setList.Name = "setList";
            this.setList.Size = new System.Drawing.Size(120, 394);
            this.setList.Sorted = true;
            this.setList.TabIndex = 0;
            this.setList.SelectedIndexChanged += new System.EventHandler(this.setList_SelectedIndexChanged_1);
            // 
            // SelectSetLabel
            // 
            this.SelectSetLabel.AutoSize = true;
            this.SelectSetLabel.Location = new System.Drawing.Point(36, 9);
            this.SelectSetLabel.Name = "SelectSetLabel";
            this.SelectSetLabel.Size = new System.Drawing.Size(56, 13);
            this.SelectSetLabel.TabIndex = 1;
            this.SelectSetLabel.Text = "Select Set";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 428);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "# of Cards in Set:";
            // 
            // cardsInSet
            // 
            this.cardsInSet.AutoSize = true;
            this.cardsInSet.Location = new System.Drawing.Point(97, 428);
            this.cardsInSet.Name = "cardsInSet";
            this.cardsInSet.Size = new System.Drawing.Size(0, 13);
            this.cardsInSet.TabIndex = 3;
            // 
            // generateCardBtn
            // 
            this.generateCardBtn.Location = new System.Drawing.Point(154, 57);
            this.generateCardBtn.Name = "generateCardBtn";
            this.generateCardBtn.Size = new System.Drawing.Size(100, 47);
            this.generateCardBtn.TabIndex = 4;
            this.generateCardBtn.Text = "Generate Pokemon Card";
            this.generateCardBtn.UseVisualStyleBackColor = true;
            this.generateCardBtn.Click += new System.EventHandler(this.generateCardBtn_ClickAsync);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(161, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Enter Card Id #";
            // 
            // cardNumberInput
            // 
            this.cardNumberInput.Location = new System.Drawing.Point(154, 31);
            this.cardNumberInput.Name = "cardNumberInput";
            this.cardNumberInput.Size = new System.Drawing.Size(100, 20);
            this.cardNumberInput.TabIndex = 6;
            this.cardNumberInput.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RarityTxt);
            this.groupBox1.Controls.Add(this.ArtistTxt);
            this.groupBox1.Controls.Add(this.NumberTxt);
            this.groupBox1.Controls.Add(this.SubtypeTxt);
            this.groupBox1.Controls.Add(this.SupertypeTxt);
            this.groupBox1.Controls.Add(this.NameTxt);
            this.groupBox1.Location = new System.Drawing.Point(154, 110);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Basic Information";
            // 
            // RarityTxt
            // 
            this.RarityTxt.AutoSize = true;
            this.RarityTxt.Location = new System.Drawing.Point(6, 82);
            this.RarityTxt.Name = "RarityTxt";
            this.RarityTxt.Size = new System.Drawing.Size(37, 13);
            this.RarityTxt.TabIndex = 8;
            this.RarityTxt.Text = "Rarity:";
            // 
            // ArtistTxt
            // 
            this.ArtistTxt.AutoSize = true;
            this.ArtistTxt.Location = new System.Drawing.Point(6, 69);
            this.ArtistTxt.Name = "ArtistTxt";
            this.ArtistTxt.Size = new System.Drawing.Size(33, 13);
            this.ArtistTxt.TabIndex = 9;
            this.ArtistTxt.Text = "Artist:";
            // 
            // NumberTxt
            // 
            this.NumberTxt.AutoSize = true;
            this.NumberTxt.Location = new System.Drawing.Point(6, 56);
            this.NumberTxt.Name = "NumberTxt";
            this.NumberTxt.Size = new System.Drawing.Size(47, 13);
            this.NumberTxt.TabIndex = 10;
            this.NumberTxt.Text = "Number:";
            // 
            // SubtypeTxt
            // 
            this.SubtypeTxt.AutoSize = true;
            this.SubtypeTxt.Location = new System.Drawing.Point(6, 43);
            this.SubtypeTxt.Name = "SubtypeTxt";
            this.SubtypeTxt.Size = new System.Drawing.Size(57, 13);
            this.SubtypeTxt.TabIndex = 9;
            this.SubtypeTxt.Text = "Subtypes: ";
            // 
            // SupertypeTxt
            // 
            this.SupertypeTxt.AutoSize = true;
            this.SupertypeTxt.Location = new System.Drawing.Point(6, 29);
            this.SupertypeTxt.Name = "SupertypeTxt";
            this.SupertypeTxt.Size = new System.Drawing.Size(58, 13);
            this.SupertypeTxt.TabIndex = 8;
            this.SupertypeTxt.Text = "Supertype:";
            // 
            // NameTxt
            // 
            this.NameTxt.AutoSize = true;
            this.NameTxt.Location = new System.Drawing.Point(6, 16);
            this.NameTxt.Name = "NameTxt";
            this.NameTxt.Size = new System.Drawing.Size(63, 13);
            this.NameTxt.TabIndex = 0;
            this.NameTxt.Text = "Card Name:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ReleaseDateTxt);
            this.groupBox2.Controls.Add(this.TotalTxt);
            this.groupBox2.Controls.Add(this.PrintedTotalTxt);
            this.groupBox2.Controls.Add(this.SetSeriesTxt);
            this.groupBox2.Controls.Add(this.SetNameTxt);
            this.groupBox2.Location = new System.Drawing.Point(154, 216);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Set Information";
            // 
            // ReleaseDateTxt
            // 
            this.ReleaseDateTxt.AutoSize = true;
            this.ReleaseDateTxt.Location = new System.Drawing.Point(6, 69);
            this.ReleaseDateTxt.Name = "ReleaseDateTxt";
            this.ReleaseDateTxt.Size = new System.Drawing.Size(75, 13);
            this.ReleaseDateTxt.TabIndex = 9;
            this.ReleaseDateTxt.Text = "Release Date:";
            // 
            // TotalTxt
            // 
            this.TotalTxt.AutoSize = true;
            this.TotalTxt.Location = new System.Drawing.Point(6, 56);
            this.TotalTxt.Name = "TotalTxt";
            this.TotalTxt.Size = new System.Drawing.Size(34, 13);
            this.TotalTxt.TabIndex = 10;
            this.TotalTxt.Text = "Total:";
            // 
            // PrintedTotalTxt
            // 
            this.PrintedTotalTxt.AutoSize = true;
            this.PrintedTotalTxt.Location = new System.Drawing.Point(6, 43);
            this.PrintedTotalTxt.Name = "PrintedTotalTxt";
            this.PrintedTotalTxt.Size = new System.Drawing.Size(70, 13);
            this.PrintedTotalTxt.TabIndex = 11;
            this.PrintedTotalTxt.Text = "Printed Total:";
            // 
            // SetSeriesTxt
            // 
            this.SetSeriesTxt.AutoSize = true;
            this.SetSeriesTxt.Location = new System.Drawing.Point(6, 29);
            this.SetSeriesTxt.Name = "SetSeriesTxt";
            this.SetSeriesTxt.Size = new System.Drawing.Size(39, 13);
            this.SetSeriesTxt.TabIndex = 12;
            this.SetSeriesTxt.Text = "Series:";
            // 
            // SetNameTxt
            // 
            this.SetNameTxt.AutoSize = true;
            this.SetNameTxt.Location = new System.Drawing.Point(6, 16);
            this.SetNameTxt.Name = "SetNameTxt";
            this.SetNameTxt.Size = new System.Drawing.Size(57, 13);
            this.SetNameTxt.TabIndex = 13;
            this.SetNameTxt.Text = "Set Name:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.SetLegalTxt);
            this.groupBox3.Controls.Add(this.CardLegalTxt);
            this.groupBox3.Location = new System.Drawing.Point(154, 322);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(200, 51);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Legalities Information";
            // 
            // SetLegalTxt
            // 
            this.SetLegalTxt.AutoSize = true;
            this.SetLegalTxt.Location = new System.Drawing.Point(7, 29);
            this.SetLegalTxt.Name = "SetLegalTxt";
            this.SetLegalTxt.Size = new System.Drawing.Size(76, 13);
            this.SetLegalTxt.TabIndex = 1;
            this.SetLegalTxt.Text = "Set Legalities: ";
            // 
            // CardLegalTxt
            // 
            this.CardLegalTxt.AutoSize = true;
            this.CardLegalTxt.Location = new System.Drawing.Point(6, 16);
            this.CardLegalTxt.Name = "CardLegalTxt";
            this.CardLegalTxt.Size = new System.Drawing.Size(79, 13);
            this.CardLegalTxt.TabIndex = 0;
            this.CardLegalTxt.Text = "Card Legalities:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(362, 450);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cardNumberInput);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.generateCardBtn);
            this.Controls.Add(this.cardsInSet);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SelectSetLabel);
            this.Controls.Add(this.setList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox setList;
        private System.Windows.Forms.Label SelectSetLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label cardsInSet;
        private System.Windows.Forms.Button generateCardBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox cardNumberInput;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label NameTxt;
        private System.Windows.Forms.Label SubtypeTxt;
        private System.Windows.Forms.Label SupertypeTxt;
        private System.Windows.Forms.Label RarityTxt;
        private System.Windows.Forms.Label ArtistTxt;
        private System.Windows.Forms.Label NumberTxt;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label ReleaseDateTxt;
        private System.Windows.Forms.Label TotalTxt;
        private System.Windows.Forms.Label PrintedTotalTxt;
        private System.Windows.Forms.Label SetSeriesTxt;
        private System.Windows.Forms.Label SetNameTxt;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label SetLegalTxt;
        private System.Windows.Forms.Label CardLegalTxt;
    }
}

