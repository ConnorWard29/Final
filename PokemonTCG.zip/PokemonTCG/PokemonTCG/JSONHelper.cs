﻿using Newtonsoft.Json;
using PokemonTCG.Objects;
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace PokemonTCG
{
    class JSONHelper
    {
        static readonly HttpClient client = new HttpClient();

        public static async Task<Card> GeneratePokemonCard(string set, int ID)
        {
            Card generatedCard = new Card();
            string URL = "https://api.pokemontcg.io/v2/cards/" + set + "-" + ID;
            try
            {
                HttpResponseMessage response = await client.GetAsync(URL);
                response.EnsureSuccessStatusCode();
                string responseBodyP = await response.Content.ReadAsStringAsync();

                generatedCard = JsonConvert.DeserializeObject<Card>(responseBodyP);
            }
            catch (HttpRequestException e)
            {
                Console.WriteLine("\nException Caught!");
                Console.WriteLine("Message :{0} ", e.Message);
            }
            return generatedCard;
        }
    }
}
